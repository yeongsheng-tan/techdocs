#ifndef GUARD_median_h
#define GUARD_median_h

// `median.h'--final version
#include <vector>
double median(std::vector<double>);

#endif


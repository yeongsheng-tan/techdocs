template <class T>
T max(const T& left, const T& right)
{	
	return left > right ? left : right;
}

